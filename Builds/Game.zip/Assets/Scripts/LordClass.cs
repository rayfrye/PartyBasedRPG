﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class LordClass: MonoBehaviour 
{
	public int id;
	public string lordclassName;
	public string description;
	public int attack;
	public int defense;
	public int speed;
	public int attackRange;
	public int maxHealth;
	public Sprite sprite;
}
