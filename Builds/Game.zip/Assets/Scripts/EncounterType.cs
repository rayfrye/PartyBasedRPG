﻿using UnityEngine;
using System.Collections;

public class EncounterType : MonoBehaviour 
{
	public int id;
	public string encountertypeName;
}
