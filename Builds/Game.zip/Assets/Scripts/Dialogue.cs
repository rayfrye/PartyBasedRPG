﻿using UnityEngine;
using System.Collections;

public class Dialogue : MonoBehaviour 
{
	public int id;
	public string mainText;

	public int numOptions;

	public string option1Text;
	public string option1Action;

}
