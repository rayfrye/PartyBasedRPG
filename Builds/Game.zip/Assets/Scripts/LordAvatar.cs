﻿using UnityEngine;
using System.Collections;

public class LordAvatar : MonoBehaviour 
{
	public int lordID;
}
