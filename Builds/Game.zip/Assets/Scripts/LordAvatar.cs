﻿using UnityEngine;
using System.Collections;

public class LordAvatar : MonoBehaviour 
{
	public int lordID;
	public string facingDir;

	public int row;
	public int col;
}
