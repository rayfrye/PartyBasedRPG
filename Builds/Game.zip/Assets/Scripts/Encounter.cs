﻿using UnityEngine;
using System.Collections;

public class Encounter : MonoBehaviour 
{
	public int id;
	public string encounterName;
	public int typeid;
	public string coroutine;
	public object[] coroutineParams;
}
